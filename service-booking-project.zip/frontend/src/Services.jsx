import { useState } from "react";

export default function Services() {
  const [formData, setFormData] = useState({
    name: "", phone: "", vehicle: "", service: "", date: "", address: ""
  });
  const [message, setMessage] = useState("");

  const handleChange = (e) => {
    setFormData({...formData,[e.target.name]: e.target.value});
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    const res = await fetch("http://localhost:5000/book-service",{
      method:"POST",
      headers:{"Content-Type":"application/json"},
      body: JSON.stringify(formData)
    });

    const data = await res.json();
    setMessage(data.message);
  };

  return (
    <div>
      <h2>Service Booking Form</h2>
      <form onSubmit={handleSubmit}>
        <input name="name" placeholder="Name" onChange={handleChange} required />
        <input name="phone" placeholder="Phone" onChange={handleChange} required />
        <input name="vehicle" placeholder="Vehicle" onChange={handleChange} required />
        <input name="service" placeholder="Service" onChange={handleChange} required />
        <input type="date" name="date" onChange={handleChange} required />
        <textarea name="address" placeholder="Address" onChange={handleChange} required />
        <button type="submit">Book Service</button>
      </form>
      <p>{message}</p>
    </div>
  );
}

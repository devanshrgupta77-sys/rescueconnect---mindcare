from flask import Flask, request, jsonify
from flask_cors import CORS
import sqlite3

app = Flask(__name__)
CORS(app)
DB = "database.db"

def init_db():
    conn = sqlite3.connect(DB)
    cur = conn.cursor()
    cur.execute("""
    CREATE TABLE IF NOT EXISTS bookings(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        phone TEXT NOT NULL,
        vehicle TEXT NOT NULL,
        service TEXT NOT NULL,
        booking_date TEXT NOT NULL,
        address TEXT NOT NULL
    )
    """)
    conn.commit()
    conn.close()

init_db()

@app.route("/book-service", methods=["POST"])
def book_service():
    data = request.get_json()

    conn = sqlite3.connect(DB)
    cur = conn.cursor()
    cur.execute(
        "INSERT INTO bookings(name,phone,vehicle,service,booking_date,address) VALUES(?,?,?,?,?,?)",
        (
            data["name"],
            data["phone"],
            data["vehicle"],
            data["service"],
            data["date"],
            data["address"],
        ),
    )
    conn.commit()
    conn.close()

    return jsonify({"success": True, "message": "Booking submitted successfully"})

@app.route("/bookings")
def bookings():
    conn = sqlite3.connect(DB)
    conn.row_factory = sqlite3.Row
    rows = [dict(r) for r in conn.execute("SELECT * FROM bookings")]
    conn.close()
    return jsonify(rows)

if __name__ == "__main__":
    app.run(debug=True, port=5000)
